import numpy
name = "example-pkg-3"
print "herp derp 3!"
