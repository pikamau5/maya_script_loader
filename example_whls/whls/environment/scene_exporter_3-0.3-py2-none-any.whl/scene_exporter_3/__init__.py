import scene_exporter as se
exportUi = se.ExportUI()
exportUi.setup_ui()
exportUi.show()